import { NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabase/server";
import { getWhopUserId } from "@/lib/whop/getUserId";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string; submissionId: string }> }
) {
  const { id: jobId, submissionId } = await params;

  const userId = await getWhopUserId();

  // Load job to verify creator
  const { data: job } = await supabaseServer
    .from("jobs")
    .select("id, creator_whop_user_id, status")
    .eq("id", jobId)
    .single();

  if (!job) {
    return NextResponse.json({ error: "Job not found" }, { status: 404 });
  }

  if (job.creator_whop_user_id !== userId) {
    return NextResponse.json({ error: "Not authorized" }, { status: 403 });
  }

  // Approve submission
  const { error: subErr } = await supabaseServer
    .from("submissions")
    .update({ status: "approved" })
    .eq("id", submissionId)
    .eq("job_id", jobId);

  if (subErr) {
    return NextResponse.json({ error: subErr.message }, { status: 500 });
  }

  // Close job (Step 3)
  const { error: jobErr } = await supabaseServer
    .from("jobs")
    .update({ status: "closed" })
    .eq("id", jobId);

  if (jobErr) {
    return NextResponse.json({ error: jobErr.message }, { status: 500 });
  }

  // Optional: auto-reject other pending submissions
  await supabaseServer
    .from("submissions")
    .update({ status: "rejected" })
    .eq("job_id", jobId)
    .neq("id", submissionId)
    .eq("status", "pending");

  return NextResponse.redirect(new URL(`/jobs/${jobId}`, req.url), 303);
}
